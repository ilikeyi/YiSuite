﻿ConvertFrom-StringData -StringData @'
	# en-US
	# English (United States)

	FirstDeployment           = First experience deployment
	FirstDeploymentPopup      = Pop up the main interface
	FirstExpFinishOnDemand    = Allow the first pre-experience, as planned
	SettingLangAndKeyboard    = Set system language and keyboard
	SettingUTF8               = Beta: Global language support using Unicode UTF-8
	SettingUTF8Tips           = May cause new problems after use.
	SettingLocale             = Set system locale
	SettingLocaleTips         = Valid when no deployment locale tag exists.
	PreAppxCleanup            = Appx cleanup maintenance tasks
	CleanupOndemandLP         = Prevent cleanup of unused feature-on-demand language packs
	CleanupUnusedLP           = Prevent cleaning of unused language packs
	Restricted                = Restore Powershell execution strategy: restricted
	DiskSearch                = Search plan:
	DiskSearchFind            = Searched, running: {0}
	DeployCleanup             = Clean up the Deploy directory
	DeployTask                = Deployment tasks
	Reboot                    = Restart the computer
	NetworkLocationWizard     = Network Location Wizard
	LangMul                   = Multilingual
	LangSingle                = Monolingual
	RandomlyWaitSel           = Wait for the randomly selected language
	RandomlySelResults        = Randomly select results
	LanguageInstalled         = The system has a language pack installed
	SetLang                   = Set system preferred language: \
	SetTimezone               = Set time zone: \
	KeyboardSequence          = Keyboard sequence: \
	Wubi                      = Wubi
	Pinyi                     = Pinyin
	VolumeLabel               = Set system disk volume label: {0}
	SelectVolumename          = Select the "System Disk" volume label name
	Exclude                   = Defender Exclude
	FixMainFolder             = Repair {0} Directory Icon
	Authority                 = Hide directory or file
	NextDelete                = After logging in next time, clean up the bonus solution
'@
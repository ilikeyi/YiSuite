﻿ConvertFrom-StringData -StringData @'
	# de-DE
	# German (Germany)

	FontsUI                   = Segoe UI
	Mainname                  = Bereitstellungs-Engine: Yi's Suite
	Learn                     = Studie
	MainHisName               = Bonuslösung
	Location                  = Offener Standort
	About                     = Über
	Reset                     = Zurücksetzen
	AddTo                     = hinzufügen
	Instl                     = installieren
	ItInstalled               = Installiert
	Close                     = Schließen
	Auto                      = automatisch
	Disable                   = Deaktivieren
	Enabled                   = aktivieren
	Setting                   = Einstellung
	Restore                   = Wiederherstellen
	CLearn                    = sauber
	Operable                  = Betriebsfähig
	Inoperable                = funktionsunfähig
	Optimize                  = Optimierung
	Hide                      = verstecken
	Show                      = zeigen
	Delete                    = löschen
	Done                      = Fertig
	OK                        = OK
	Cancel                    = abbrechen
	AllSel                    = alles auswählen
	AllClear                  = Alles löschen
	Refresh                   = auffrischen
	RefreshModules            = Hot-Refresh aller Module
	ForceUpdate               = Prüfung und Aktualisierung erzwingen
	Necessary                 = Notwendige Software
	MostUsedSoftware          = Häufig verwendete Software
	System                    = System
	Service                   = Dienst
	TaskBar                   = alle Icons in der Taskleiste
	DeskIcon                  = Desktop Symbol
	InstallFonts              = Schriftarten installieren
	SettingTo                 = auf {0} gesetzt
	SwitchLanguage            = prache wechseln
	PleaseChoose              = Bitte wählen
	PleaseChooseMain          = Verknüpfung oder Auswahl
	FailedCreateFolder        = Fehler beim Erstellen des Verzeichnisses: \
	ToMsg                     = \n   Nach {0} Sekunden automatisch zum Hauptmenü zurückkehren.
	ToQuit                    = \n   Beendet das Hauptmenü in {0} Sekunden.
	Restart                   = Neustart, um wirksam zu werden
	AdvOption                 = optionale Funktion

	StartDown                 = Download starten
	ConnectTo                 = Verbinden mit
	FileName                  = Dateiname
	SaveTo                    = Speichern unter
	NotAvailable              = Status: Nicht verfügbar
	ExistingPacker            = Vorhandenes Installationspaket
	ExistingInstlPacker       = Vorhandenes komprimiertes Paket
	Unpacking                 = Auspacken
	QucikRun                  = Schnelllauf:
	WaitDone                  = Auf Abschluss warten:
	Parameter                 = Parameter:
	ErrorDown                 = Beim Herunterladen ist ein Fehler aufgetreten
	UserCancel                = Der Benutzer hat den Vorgang abgebrochen.

	VerifyNameTips            = Lassen Sie nur die Kombination aus englischen Buchstaben und Zahlen zu und dürfen keine anderen Zeichen enthalten: Leerzeichen und die Länge darf nicht mehr als 260 Zeichen betragen, \\ / : * ? & @ ! "" < > |
	FolderLabel               = Benutzerdefiniertes Verzeichnispräfix
	NoSetFolderLabel          = Das benutzerdefinierte Verzeichnispräfix ist nicht festgelegt
	ISO9660TipsErrorSpace     = Darf nicht enthalten: führende und nachgestellte Leerzeichen
	ISO9660TipsErrorOther     = Darf nicht enthalten: \\ / : * ? & @ ! "" < > |
	ISOLengthError            = Die Etikettenlänge darf nicht mehr als {0} Zeichen betragen
	Help                      = Helfen
	WorkDone                  = Wenn Sie fertig sind, drücken Sie eine beliebige Taste, um zur Hauptoberfläche zurückzukehren ...
	Short_Cmd                 = Verknüpfungen
'@
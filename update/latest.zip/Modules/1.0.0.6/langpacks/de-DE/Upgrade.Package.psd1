﻿ConvertFrom-StringData -StringData @'
	# de-DE
	# German (Germany)

	UpdateCreate              = Upgrade Paket erstellen
	UpdateLow                 = Mindestanforderungen: \
	UpCreateRear              = Was ist nach der Erstellung zu tun
	UpCreateASC               = Fügen Sie dem Upgrade Paket eine PGP Signatur hinzu
	CreateASCPwd              = Zertifikatskennwort
	CreateASCAuthor           = Unterzeichner
	CreateASCAuthorTips       = Keine Unterzeichner ausgewählt.
	UpCreateSHA256            = Generieren Sie das Upgrade Paket .SHA-256
	SelectFromError           = Fehler
	Uping                     = Erstellen
	SkipCreate                = Generierung überspringen, nicht gefunden
	ZipStatus                 = 7-Zip ist nicht installiert.
	ASCStatus                 = Gpg4win ist nicht installiert.
'@
﻿ConvertFrom-StringData -StringData @'
	# ja-JP
	# Japanese (Japan)

	FontsUI                   = Yu Gothic UI
	Mainname                  = デプロイメント エンジン: Yi のスイート
	Learn                     = 勉強
	MainHisName               = ボーナスソリューション
	Location                  = オープンロケーション
	About                     = 約
	Reset                     = リセット
	AddTo                     = 追加
	Instl                     = インストール
	ItInstalled               = インストール済み
	Close                     = 閉じる
	Auto                      = 自动自動
	Disable                   = 無効
	Enabled                   = 有効
	Setting                   = 設定
	Restore                   = 復元
	CLearn                    = きれい
	Operable                  = 操作可能
	Inoperable                = 操作不能
	Optimize                  = 最適化
	Hide                      = 隠れる
	Show                      = 見せる
	Delete                    = 削除
	Done                      = 完了
	OK                        = 決定
	Cancel                    = キャンセル
	AllSel                    = すべて選択
	AllClear                  = すべてクリア
	Refresh                   = 更新
	RefreshModules            = すべてのモジュールをホットリフレッシュします
	ForceUpdate               = チェックと更新を強制します
	Necessary                 = 必要なソフトウェア
	MostUsedSoftware          = よく使われるソフトウェア
	System                    = システム
	Service                   = サービス
	TaskBar                   = タスクバー内のすべてのアイコン
	DeskIcon                  = デスクトップアイコン
	InstallFonts              = フォントをインストールします
	SettingTo                 = に設定 {0}
	SwitchLanguage            = 言語の切り替え
	LanguageCode              = ゾーンマーカー
	PleaseChoose              = 選択してください
	PleaseChooseMain          = ショートカット コマンドまたは選択
	FailedCreateFolder        = ディレクトリの作成に失敗しました：
	ToMsg                     = \n   {0} 秒後に自動的にメインメニューに戻ります。
	ToQuit                    = \n   {0} 秒でメインメニューを終了します。
	Restart                   = 再起動して有効にします
	AdvOption                 = オプション機能

	StartDown                 = ダウンロードを開始
	ConnectTo                 = 接続先
	FileName                  = ファイル名
	SaveTo                    = に保存
	NotAvailable              = ステータス：利用不可
	ExistingPacker            = 既存のインストールパッケージ
	ExistingInstlPacker       = 既存の圧縮パッケージ
	Unpacking                 = 開梱
	QucikRun                  = クイックラン：
	WaitDone                  = 完了を待ちます：
	Parameter                 = パラメータ：
	ErrorDown                 = ダウンロード中にエラーが発生しました
	UserCancel                = ユーザーが操作をキャンセルしました。

	VerifyNameTips            = 英語の文字と数字の組み合わせのみを許可し、他の文字（スペース）を含めることはできません。長さは 260 文字を超えることはできません、\\ / : * ? & @ ! "" < > |
	FolderLabel               = カスタムディレクトリプレフィックス
	NoSetFolderLabel          = カスタムディレクトリプレフィックスが設定されていません
	ISO9660TipsErrorSpace     = 含めることはできません：先頭と末尾のスペース
	ISO9660TipsErrorOther     = 含めることはできません：\\ / : * ? & @ ! "" < > |
	ISOLengthError            = ラベルの長さは {0} 文字を超えることはできません
	Help                      = ヘルプ
	WorkDone                  = 完了し, メインインターフェイスに戻って任意のキーを押します...
	Short_Cmd                 = ショートカットコマンド
'@
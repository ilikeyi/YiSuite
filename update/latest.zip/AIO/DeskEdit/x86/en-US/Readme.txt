Author: BlueLife, Velociraptor
www.sordum.org

#################--Desktop.ini Editor v1.1--#################
(Monday, September 27, 2021) - Whats New

[Added] - Encode selection under the File menu
[Fixed] - The font in the interface is too small
[Added] - Option to add CLSID to ini File
[Added] - Some code Improvements

#################--Desktop.ini Editor v1.0--#################
(Wednesday , August 30, 2017)

This Software is simplify the Desktop.ini operations like setting custom folder icons,Folder Info Tips, adding CLSID, resetting folder settings to default etc.


